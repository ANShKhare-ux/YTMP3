const { spawn, execFile, execFileSync } = require('child_process');
const path = require('path');
const fs = require('fs');
const { getYtDlpPath, getFfmpegPath, getFfmpegLocation, getBinDir } = require('./binManager');

const DOWNLOADS_DIR = path.join(__dirname, 'downloads');
if (!fs.existsSync(DOWNLOADS_DIR)) {
  fs.mkdirSync(DOWNLOADS_DIR, { recursive: true });
}

const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
const HISTORY_FILE = path.join(DATA_DIR, 'history.json');

// In-memory active jobs tracker
const jobs = new Map();

/**
 * Load completed jobs from persistent history file into memory on startup
 */
function loadPersistentHistory() {
  try {
    if (fs.existsSync(HISTORY_FILE)) {
      const data = JSON.parse(fs.readFileSync(HISTORY_FILE, 'utf8'));
      if (Array.isArray(data)) {
        for (const item of data) {
          if (item && item.id) {
            jobs.set(item.id, item);
          }
        }
        console.log(`[converter] Loaded ${data.length} persistent history records.`);
      }
    }
  } catch (err) {
    console.warn('[converter] Failed to load persistent history:', err.message);
  }
}
loadPersistentHistory();

/**
 * Append or update a completed job in persistent history
 */
function savePersistentHistory(job) {
  try {
    let list = [];
    if (fs.existsSync(HISTORY_FILE)) {
      try {
        list = JSON.parse(fs.readFileSync(HISTORY_FILE, 'utf8'));
      } catch {}
    }
    const cleanJob = {
      id: job.id,
      url: job.url,
      format: job.format,
      quality: job.quality,
      isVideo: job.isVideo,
      status: 'completed',
      progress: 100,
      title: job.title || 'Audio File',
      artist: job.artist || 'Media Artist',
      thumbnail: job.thumbnail || '',
      duration: job.duration || 0,
      filePath: job.filePath,
      fileName: job.fileName,
      createdAt: job.createdAt || Date.now()
    };
    list = [cleanJob, ...list.filter(item => item.id !== job.id)].slice(0, 50);
    fs.writeFileSync(HISTORY_FILE, JSON.stringify(list, null, 2), 'utf8');
  } catch (err) {
    console.warn('[converter] Failed to save history to disk:', err.message);
  }
}

// Clean up files older than 2 hours every 30 minutes to prevent disk exhaustion and memory leaks
function cleanOldDownloads() {
  try {
    const now = Date.now();
    const maxAge = 2 * 60 * 60 * 1000;
    if (fs.existsSync(DOWNLOADS_DIR)) {
      const files = fs.readdirSync(DOWNLOADS_DIR);
      for (const file of files) {
        const fullPath = path.join(DOWNLOADS_DIR, file);
        try {
          const stats = fs.statSync(fullPath);
          if (stats.isFile() && now - stats.mtimeMs > maxAge) {
            fs.unlinkSync(fullPath);
          }
        } catch {}
      }
    }

    // Evict old jobs from memory if their physical files are deleted
    for (const [id, job] of jobs.entries()) {
      if ((job.status === 'completed' || job.status === 'failed' || job.status === 'cancelled') &&
          now - (job.createdAt || 0) > maxAge) {
        if (!job.filePath || !fs.existsSync(job.filePath)) {
          jobs.delete(id);
        }
      }
    }
  } catch {}
}
setInterval(cleanOldDownloads, 30 * 60 * 1000).unref();

/**
 * Format seconds into HH:MM:SS or MM:SS
 */
function formatDuration(seconds) {
  if (!seconds || isNaN(seconds)) return '0:00';
  const sec = Math.floor(seconds % 60);
  const min = Math.floor((seconds / 60) % 60);
  const hrs = Math.floor(seconds / 3600);
  const pad = (n) => n.toString().padStart(2, '0');
  if (hrs > 0) {
    return `${hrs}:${pad(min)}:${pad(sec)}`;
  }
  return `${min}:${pad(sec)}`;
}

/**
 * Detect social media platform from URL
 */
function detectPlatform(url) {
  const lower = url.toLowerCase();
  if (lower.includes('youtube.com') || lower.includes('youtu.be')) return 'YouTube';
  if (lower.includes('instagram.com') || lower.includes('instagr.am')) return 'Instagram';
  if (lower.includes('tiktok.com')) return 'TikTok';
  if (lower.includes('twitter.com') || lower.includes('x.com') || lower.includes('t.co')) return 'Twitter / X';
  if (lower.includes('facebook.com') || lower.includes('fb.watch') || lower.includes('fb.com')) return 'Facebook';
  if (lower.includes('reddit.com') || lower.includes('redd.it')) return 'Reddit';
  if (lower.includes('soundcloud.com')) return 'SoundCloud';
  if (lower.includes('twitch.tv')) return 'Twitch';
  if (lower.includes('vimeo.com')) return 'Vimeo';
  if (lower.includes('pinterest.com') || lower.includes('pin.it')) return 'Pinterest';
  if (lower.includes('bilibili.com')) return 'Bilibili';
  if (lower.includes('threads.net')) return 'Threads';
  return 'Web Media';
}

/**
 * Clean & normalize any social media or web URL with strict SSRF & protocol controls
 */
function normalizeUrl(rawUrl) {
  if (!rawUrl || typeof rawUrl !== 'string') {
    throw new Error('URL is required');
  }
  let url = rawUrl.trim();

  // Prevent null-byte injection
  if (url.includes('\0')) {
    throw new Error('Invalid URL format: null bytes detected.');
  }

  // If protocol scheme is provided, verify it is strictly HTTP or HTTPS
  const schemeMatch = url.match(/^([a-zA-Z][a-zA-Z0-9+.-]*):/);
  if (schemeMatch) {
    const scheme = schemeMatch[1].toLowerCase();
    if (scheme !== 'http' && scheme !== 'https') {
      throw new Error('Only HTTP and HTTPS URLs are authorized.');
    }
  } else {
    // Add default https protocol if omitted
    url = 'https://' + url;
  }

  let parsed;
  try {
    parsed = new URL(url);
  } catch (e) {
    throw new Error('Please enter a valid link from YouTube, Instagram, TikTok, Twitter/X, Facebook, SoundCloud, Reddit, etc.');
  }

  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new Error('Only HTTP and HTTPS URLs are authorized.');
  }

  const hostname = parsed.hostname.toLowerCase();
  if (!hostname) {
    throw new Error('Please enter a valid link from YouTube, Instagram, TikTok, Twitter/X, Facebook, SoundCloud, Reddit, etc.');
  }

  // SSRF & Local/Private IP / Cloud Metadata Prevention
  const isLoopback = (
    hostname === 'localhost' ||
    hostname === '127.0.0.1' ||
    hostname === '0.0.0.0' ||
    hostname === '::1' ||
    hostname === '[::1]' ||
    hostname.startsWith('127.') ||
    hostname === '169.254.169.254' ||
    hostname === 'metadata.google.internal'
  );

  // Private RFC 1918 & Carrier-grade NAT IPv4 check
  const isPrivateIp = (
    /^10\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(hostname) ||
    /^172\.(1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3}$/.test(hostname) ||
    /^192\.168\.\d{1,3}\.\d{1,3}$/.test(hostname) ||
    /^100\.(6[4-9]|[7-9]\d|1[0-1]\d|12[0-7])\.\d{1,3}\.\d{1,3}$/.test(hostname) ||
    /^169\.254\.\d{1,3}\.\d{1,3}$/.test(hostname)
  );

  if (isLoopback || isPrivateIp) {
    throw new Error('Access to local, internal, or cloud metadata network addresses is strictly prohibited.');
  }

  if (!hostname.includes('.')) {
    throw new Error('Please enter a valid link from YouTube, Instagram, TikTok, Twitter/X, Facebook, SoundCloud, Reddit, etc.');
  }

  return url;
}

/**
 * Check if a cookies.txt file exists in the server or root directory
 */
function getCookiePath() {
  const serverCookie = path.join(__dirname, 'cookies.txt');
  const rootCookie = path.join(__dirname, '..', 'cookies.txt');
  if (fs.existsSync(serverCookie)) return serverCookie;
  if (fs.existsSync(rootCookie)) return rootCookie;
  return null;
}

/**
 * Get Video/Audio Metadata via yt-dlp across all social platforms
 */
function getVideoInfo(rawUrl) {
  return new Promise((resolve, reject) => {
    let url;
    try {
      url = normalizeUrl(rawUrl);
    } catch (err) {
      return reject(err);
    }

    const lowerUrl = typeof url === 'string' ? url.toLowerCase() : '';
    const isYouTube = lowerUrl.includes('youtube.com') || lowerUrl.includes('youtu.be');
    const ytDlp = getYtDlpPath();
    const cookiePath = getCookiePath();
    const cookieFlags = cookiePath ? ['--cookies', cookiePath] : [];

    const args = [
      '--dump-single-json',
      '--no-warnings',
      '--no-playlist',
      '--no-check-certificates',
      ...(isYouTube && !cookiePath ? ['--extractor-args', 'youtube:player_client=ios,android'] : []),
      ...cookieFlags,
      '--user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      '--js-runtimes', 'node',
      '--',
      url
    ];

    execFile(ytDlp, args, { maxBuffer: 20 * 1024 * 1024 }, (error, stdout, stderr) => {
      if (error) {
        console.error('[converter] Error fetching media info:', stderr || error.message);
        
        let errorMsg = 'Unable to fetch media details. Please verify the URL or try again.';
        const errText = (stderr || error.message || '').toString();

        if (errText.includes('This video is unavailable') || errText.includes('Video unavailable')) {
          errorMsg = 'This media is unavailable or has been deleted.';
        } else if (errText.includes('Private') || errText.includes('private')) {
          errorMsg = 'This content is marked private or restricted.';
        } else if (errText.includes('Sign in to confirm your age')) {
          errorMsg = 'This media is age-restricted and requires sign-in.';
        } else if (errText.includes('Sign in') || errText.includes('bot')) {
          errorMsg = 'Platform verification or login required. Please try another link.';
        } else {
          const match = errText.match(/ERROR:\s*(?:\[[^\]]+\]\s*)?([^\r\n]+)/i);
          if (match && match[1]) {
            errorMsg = match[1].trim();
          }
        }

        return reject(new Error(errorMsg));
      }

      try {
        const data = JSON.parse(stdout);

        // Pick highest resolution thumbnail
        let thumbnail = data.thumbnail;
        if (Array.isArray(data.thumbnails) && data.thumbnails.length > 0) {
          const sorted = [...data.thumbnails].sort((a, b) => (b.width || 0) - (a.width || 0));
          thumbnail = sorted[0].url || thumbnail;
        }

        const duration = data.duration || 0;
        const platform = detectPlatform(url);
        const info = {
          id: data.id,
          url: data.webpage_url || url,
          title: data.title || `${platform} Media`,
          uploader: data.uploader || data.channel || data.creator || `${platform} Creator`,
          platform: platform,
          channelUrl: data.channel_url || data.uploader_url || null,
          duration: duration,
          durationFormatted: formatDuration(duration),
          isUltraLong: duration >= 7200, // >= 2 hours (handles 10h, 24h, 100h+)
          thumbnail: thumbnail,
          viewCount: data.view_count || data.like_count || 0,
          uploadDate: data.upload_date || '',
          description: (data.description || '').slice(0, 300)
        };

        resolve(info);
      } catch (parseErr) {
        console.error('[converter] JSON parse error:', parseErr.message);
        reject(new Error('Failed to parse media information.'));
      }
    });
  });
}

let aria2Cache = null;

/**
 * Check if aria2c external downloader is available on system or in bin directory
 */
function isAria2Available(forceRecheck = false) {
  if (!forceRecheck && aria2Cache !== null) {
    return aria2Cache;
  }

  // 1. Check local bin directory (server/bin)
  try {
    const binDir = getBinDir();
    const localAria2 = path.join(binDir, process.platform === 'win32' ? 'aria2c.exe' : 'aria2c');
    if (fs.existsSync(localAria2)) {
      execFileSync(localAria2, ['-v'], { stdio: 'ignore', timeout: 3000 });
      aria2Cache = true;
      return true;
    }
  } catch {}

  // 2. Check system PATH
  try {
    execFileSync('aria2c', ['-v'], { stdio: 'ignore', timeout: 3000 });
    aria2Cache = true;
    return true;
  } catch {
    aria2Cache = false;
    return false;
  }
}

/**
 * Manually set aria2 availability cache (useful for testing fallback paths)
 */
function setAria2Available(available) {
  aria2Cache = available;
}

/**
 * Build yt-dlp CLI arguments for audio or video conversion
 */
function buildConversionArgs({
  url,
  format = 'mp3',
  quality = '320k',
  outputTemplate,
  cookiePath = null,
  ffmpegLocation = null,
  useAria2 = null,
  turbo = true
}) {
  const validFormats = ['mp3', 'm4a', 'wav', 'flac', 'mp4'];
  const safeFormat = typeof format === 'string' ? format.toLowerCase() : 'mp3';
  const targetFormat = validFormats.includes(safeFormat) ? safeFormat : 'mp3';
  const isVideo = targetFormat === 'mp4';

  // Sanitize and whitelist quality values
  const validAudioQualities = ['320k', '256k', '192k', '128k', '0', '5', '9'];
  const validVideoQualities = ['1080p', '720p', '480p', 'best'];
  let targetQuality = quality;
  if (isVideo) {
    targetQuality = validVideoQualities.includes(quality) ? quality : '1080p';
  } else {
    targetQuality = validAudioQualities.includes(quality) ? quality : '320k';
  }

  const lowerUrl = typeof url === 'string' ? url.toLowerCase() : '';
  const isYouTube = lowerUrl.includes('youtube.com') || lowerUrl.includes('youtu.be');
  const cookieFlags = cookiePath ? ['--cookies', cookiePath] : [];
  const ffmpegFlags = ffmpegLocation ? ['--ffmpeg-location', ffmpegLocation] : [];

  const aria2Active = useAria2 !== null ? Boolean(useAria2) : (turbo ? isAria2Available() : false);
  const aria2Flags = aria2Active ? [
    '--downloader', 'aria2c',
    '--downloader-args', 'aria2c:-s 16 -x 16 -k 1M -j 16'
  ] : [];

  // High-speed multi-threaded acceleration flags (16 parallel chunk streams, 16MB buffer)
  const speedFlags = [
    ...(turbo ? ['-N', '16', '--buffer-size', '16M', '--http-chunk-size', '5M'] : []),
    ...(isYouTube && !cookiePath ? ['--extractor-args', 'youtube:player_client=ios,android'] : []),
    ...cookieFlags,
    ...aria2Flags,
    '--user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    '--js-runtimes', 'node',
    '--retries', '10',
    '--fragment-retries', '10',
    '--skip-unavailable-fragments',
    '--no-mtime'
  ];

  let args = [];

  if (isVideo) {
    // Video download with resolution filter & Direct Stream Copy MP4 merge
    let formatFilter = 'bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4] / bv*+ba/b';
    if (targetQuality === '1080p') {
      formatFilter = 'bv*[height<=1080][ext=mp4]+ba[ext=m4a]/bv*[height<=1080]+ba/b[height<=1080] / bv*+ba/b';
    } else if (targetQuality === '720p') {
      formatFilter = 'bv*[height<=720][ext=mp4]+ba[ext=m4a]/bv*[height<=720]+ba/b[height<=720] / bv*+ba/b';
    } else if (targetQuality === '480p') {
      formatFilter = 'bv*[height<=480][ext=mp4]+ba[ext=m4a]/bv*[height<=480]+ba/b[height<=480] / bv*+ba/b';
    }

    args = [
      '-f', formatFilter,
      '--merge-output-format', 'mp4',
      '--postprocessor-args', 'Merger:-c copy -threads 0',
      '--output', outputTemplate,
      '--newline',
      '--no-playlist',
      '--embed-metadata',
      '--embed-thumbnail',
      '--no-check-certificates',
      ...ffmpegFlags,
      ...speedFlags,
      '--',
      url
    ];
  } else {
    // Audio extraction with multi-threaded encoding or stream copy
    let audioFilter = 'ba/b';
    let postArgs = 'ExtractAudio:-threads 0';

    if (targetFormat === 'm4a') {
      // Native YouTube AAC stream copy (Instant 0-reencode)
      audioFilter = 'ba[ext=m4a]/ba/b';
      postArgs = 'ExtractAudio:-threads 0';
    } else if (targetFormat === 'mp3') {
      // Fastest multi-core MP3 encoding
      postArgs = 'ExtractAudio:-threads 0';
    }

    args = [
      '-f', audioFilter,
      '--extract-audio',
      '--audio-format', targetFormat,
      '--audio-quality', targetQuality,
      '--postprocessor-args', postArgs,
      '--output', outputTemplate,
      '--newline',
      '--no-playlist',
      '--embed-metadata',
      '--embed-thumbnail',
      '--convert-thumbnails', 'jpg',
      '--no-check-certificates',
      ...ffmpegFlags,
      ...speedFlags,
      '--',
      url
    ];
  }

  return {
    args,
    targetFormat,
    targetQuality,
    isVideo,
    useAria2: aria2Active
  };
}

/**
 * Parse a single stdout line from yt-dlp or aria2c to update job state
 */
function parseProgress(line, jobState) {
  if (!line || !jobState) return;

  // Examples:
  // [download]   5.4% of   10.23MiB at    1.24MiB/s ETA 00:08
  // [download] 100% of   10.23MiB in 00:03
  // [#123456 2.5MiB/23.4MiB(10%) CN:16 DL:2.8MiB ETA:7s]
  // [#366579 0B/23.4MiB CN:1 DL:0B]
  // [ExtractAudio] Destination: ...
  // [Metadata] Adding metadata...
  // [ThumbnailsConvertor] Converting thumbnail...

  const isYtDlpDownload = line.includes('[download]');
  const isAria2Download = line.includes('[#') && (line.includes('(') || line.includes('CN:') || line.includes('DL:'));

  if (isYtDlpDownload || isAria2Download) {
    jobState.status = 'downloading';
    const percentMatch = line.match(/(\d+(?:\.\d+)?)%/);
    if (percentMatch) {
      jobState.progress = Math.min(Math.round(parseFloat(percentMatch[1])), 95);
    }

    // Match high speeds (e.g., 28.5MiB/s, 1.2GiB/s, 450KiB/s, aria2 DL:2.8MiB or DL:2.8MiB/s, or initial DL:0B)
    const speedMatch = line.match(/(?:at|DL:)\s*([\d.]+\s*(?:[KMGTkmgt]i?)?B(?:\/s)?)/i);
    if (speedMatch) {
      const rawSpeed = speedMatch[1].trim();
      jobState.speed = rawSpeed.endsWith('/s') ? rawSpeed : `${rawSpeed}/s`;
    }

    // Match ETA (e.g., ETA 03:45, ETA:7s, ETA 01:23:45)
    const etaMatch = line.match(/ETA:?\s*([\d:smhd]+)/i);
    if (etaMatch) {
      jobState.eta = etaMatch[1];
    }

    // Match multi-gigabyte and multi-megabyte file sizes
    const sizeMatch = line.match(/(?:of\s+~?|\/)([\d.]+\s*(?:[KMGTkmgt]i?)?B)/i);
    if (sizeMatch) {
      jobState.totalSize = sizeMatch[1];
    }

    // Match fragment download progress (e.g. frag 250/1800)
    const fragMatch = line.match(/frag\s+(\d+\/\d+)/i);
    if (fragMatch) {
      jobState.fragmentInfo = fragMatch[1];
    }
  } else if (line.includes('[ExtractAudio]') || line.includes('[ffmpeg]') || line.includes('[Merger]')) {
    jobState.status = 'converting';
    jobState.progress = Math.max(jobState.progress, 92);
  } else if (line.includes('[Metadata]') || line.includes('[ThumbnailsConvertor]') || line.includes('[EmbedThumbnail]')) {
    jobState.status = 'tagging';
    jobState.progress = 98;
  }
}

/**
 * Start Conversion Job with 16-Stream Turbo Acceleration
 */
function startConversion({ url, format = 'mp3', quality = '320k', jobId, turbo = true }) {
  const ytDlp = getYtDlpPath();
  const ffmpeg = getFfmpegPath();

  // Output filename template
  const outputTemplate = path.join(DOWNLOADS_DIR, `${jobId}.%(ext)s`);

  const cookiePath = getCookiePath();
  const ffmpegLocation = getFfmpegLocation();

  const {
    args,
    targetFormat,
    targetQuality,
    isVideo,
    useAria2: activeAria2
  } = buildConversionArgs({
    url,
    format,
    quality,
    outputTemplate,
    cookiePath,
    ffmpegLocation,
    turbo
  });

  const jobState = {
    id: jobId,
    url,
    format: targetFormat,
    quality: targetQuality,
    isVideo,
    turbo: Boolean(turbo),
    downloader: activeAria2 ? 'aria2c' : 'builtin',
    parallelStreams: turbo ? 16 : 1,
    fragmentInfo: null,
    status: 'starting', // starting, downloading, converting, completed, failed
    progress: 0,
    speed: '0 KiB/s',
    eta: '--:--',
    totalSize: 'Calculating...',
    title: '',
    artist: '',
    thumbnail: '',
    duration: 0,
    filePath: null,
    fileName: null,
    error: null,
    createdAt: Date.now()
  };

  jobs.set(jobId, jobState);

  console.log(`[converter] Starting job ${jobId} (Turbo: ${Boolean(turbo)}, downloader: ${activeAria2 ? 'aria2c' : 'builtin'}): ${url} (${targetFormat}, ${targetQuality})`);

  // Ensure binDir is in PATH so yt-dlp can locate local aria2c or ffmpeg
  const binDir = getBinDir();
  const env = { ...process.env };
  const envPathKey = Object.keys(env).find(k => k.toLowerCase() === 'path') || (process.platform === 'win32' ? 'Path' : 'PATH');
  const currentPath = env[envPathKey] || '';
  if (binDir && !currentPath.includes(binDir)) {
    const updatedPath = `${binDir}${path.delimiter}${currentPath}`;
    for (const key of Object.keys(env)) {
      if (key.toLowerCase() === 'path') {
        env[key] = updatedPath;
      }
    }
    env[envPathKey] = updatedPath;
  }

  const child = spawn(ytDlp, args, { env });
  jobState.process = child;

  const parseProgressLine = (line) => {
    parseProgress(line, jobState);
  };

  child.stdout.on('data', (chunk) => {
    const lines = chunk.toString().split(/\r?\n/);
    for (const line of lines) {
      if (line.trim()) {
        parseProgressLine(line.trim());
      }
    }
  });

  let stderrBuffer = '';
  child.stderr.on('data', (chunk) => {
    const errText = chunk.toString();
    stderrBuffer += errText;
    console.warn(`[converter ${jobId} stderr]:`, errText.trim());
  });

  child.on('close', (code) => {
    if (code === 0) {
      // Find output file
      const expectedFile = path.join(DOWNLOADS_DIR, `${jobId}.${targetFormat}`);
      if (fs.existsSync(expectedFile)) {
        jobState.status = 'completed';
        jobState.progress = 100;
        jobState.filePath = expectedFile;
        jobState.fileName = `${(jobState.title || 'audio').replace(/[/\\?%*:|"<>]/g, '_')}.${targetFormat}`;
        savePersistentHistory(jobState);
        console.log(`[converter] Job ${jobId} completed successfully!`);
      } else {
        // Look for any file with jobId prefix in downloads dir
        const found = fs.readdirSync(DOWNLOADS_DIR).find(f => f.startsWith(jobId));
        if (found) {
          jobState.status = 'completed';
          jobState.progress = 100;
          jobState.filePath = path.join(DOWNLOADS_DIR, found);
          jobState.fileName = found;
          savePersistentHistory(jobState);
          console.log(`[converter] Job ${jobId} finished with file ${found}`);
        } else {
          jobState.status = 'failed';
          jobState.error = 'Output media file was not created.';
        }
      }
    } else {
      jobState.status = 'failed';
      let errorMsg = `Conversion failed (exit code ${code})`;
      if (stderrBuffer.includes('Sign in to confirm your age')) {
        errorMsg = 'This video is age-restricted and requires sign-in.';
      } else if (stderrBuffer.includes('Sign in') || stderrBuffer.includes('bot')) {
        errorMsg = 'YouTube flagged this video with bot/login verification. Try another video link or export cookies.txt.';
      } else {
        const match = stderrBuffer.match(/ERROR:\s*(?:\[[^\]]+\]\s*)?([^\r\n]+)/i);
        if (match && match[1]) {
          errorMsg = match[1].trim();
        }
      }
      jobState.error = errorMsg;
      console.error(`[converter] Job ${jobId} failed: ${errorMsg}`);

      // Clean up any incomplete partial files on error
      try {
        const partials = fs.readdirSync(DOWNLOADS_DIR).filter(f => f.startsWith(jobId));
        for (const part of partials) {
          fs.unlinkSync(path.join(DOWNLOADS_DIR, part));
        }
      } catch {}
    }
  });

  child.on('error', (err) => {
    console.error(`[converter] Job ${jobId} failed to spawn:`, err.message);
    jobState.status = 'failed';
    jobState.error = err.message;
  });

  return jobState;
}

/**
 * Get job state
 */
function getJob(jobId) {
  const job = jobs.get(jobId);
  if (!job) return null;
  // Return shallow copy without raw process object
  const { process, ...clean } = job;
  return clean;
}

/**
 * List completed history
 */
function getHistory() {
  const list = [];
  for (const [id, job] of jobs.entries()) {
    if (job.status === 'completed') {
      const { process, ...clean } = job;
      clean.isAvailable = clean.filePath ? fs.existsSync(clean.filePath) : false;
      list.push(clean);
    }
  }
  return list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
}

/**
 * Cancel an active conversion job
 */
function cancelConversion(jobId) {
  const job = jobs.get(jobId);
  if (!job) return false;
  if (job.process && job.status !== 'completed' && job.status !== 'failed') {
    try {
      job.process.kill('SIGTERM');
    } catch {}
    job.status = 'cancelled';
    job.error = 'Conversion was cancelled by user.';
    console.log(`[converter] Job ${jobId} cancelled.`);

    // Clean up partial downloads on cancellation
    setTimeout(() => {
      try {
        if (fs.existsSync(DOWNLOADS_DIR)) {
          const partials = fs.readdirSync(DOWNLOADS_DIR).filter(f => f.startsWith(jobId));
          for (const part of partials) {
            fs.unlinkSync(path.join(DOWNLOADS_DIR, part));
          }
        }
      } catch {}
    }, 400);
    return true;
  }
  return false;
}

/**
 * Get count of actively running conversions
 */
function getActiveJobCount() {
  let count = 0;
  for (const job of jobs.values()) {
    if (job.status === 'starting' || job.status === 'downloading' || job.status === 'converting' || job.status === 'tagging') {
      count++;
    }
  }
  return count;
}

module.exports = {
  getVideoInfo,
  startConversion,
  cancelConversion,
  getJob,
  getHistory,
  formatDuration,
  getActiveJobCount,
  normalizeUrl,
  DOWNLOADS_DIR,
  isAria2Available,
  setAria2Available,
  buildConversionArgs,
  parseProgress
};
